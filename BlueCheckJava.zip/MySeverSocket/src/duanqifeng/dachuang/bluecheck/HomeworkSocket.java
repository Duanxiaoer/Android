package duanqifeng.dachuang.bluecheck;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class HomeworkSocket extends Thread {
	
	Socket socket;
	
	public HomeworkSocket(Socket sc){
		this.socket = sc;
	}
	
	public void out(String out){
		try {
			socket.getOutputStream().write(out.getBytes("UTF-8"));
			socket.getOutputStream().flush();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	@Override
	public void run() {
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream(),"UTF-8"));
			String line = null;
			while((line = br.readLine()) != null){
				line = line + "\n";
				HomeworkManger.getHomeworkManger().publish(this, line);
				//System.out.println(line);
			}
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block 
			e.printStackTrace();
		}
		
	}

}
