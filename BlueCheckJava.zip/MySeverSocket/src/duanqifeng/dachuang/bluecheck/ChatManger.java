package duanqifeng.dachuang.bluecheck;

import java.util.Vector;

public class ChatManger {
	
	JiLu jilu = new JiLu();
	
	private String ���� = "����";
	private ChatManger(){}
	private static final ChatManger cm = new ChatManger();
	public static ChatManger getChatManger(){
		return cm;
	}
	
	Vector<ChatSocket> vector = new Vector<ChatSocket>();
	
	public void add(ChatSocket cs){
		vector.add(cs);
	}
	
	public void publish(ChatSocket cs,String out){
		for(int i = 0;i<vector.size();i++){
			if(i == 0)
			jilu.jilu(����,out+"\n");
			ChatSocket cschatsocket = vector.get(i);
			if(!cs.equals(cschatsocket)){
				cschatsocket.out(out);
			}
		}
	}
}
  