package duanqifeng.dachuang.bluecheck;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JOptionPane;

public class taolunSeverSocket extends Thread{
	@Override
	public void run() {
		taolun();
	}
	
	public void taolun(){
		//1-65535
				try {
					ServerSocket seversocket = new ServerSocket(12345);
					while(true)
					{
						//�������߳�
						Socket socket = seversocket.accept();
						JOptionPane.showMessageDialog(null, "�пͻ������ӱ������۶˿ڡ�������");
						//��socket���ݸ����߳�
						ChatSocket cs = new ChatSocket(socket);
						cs.start();
						ChatManger.getChatManger().add(cs);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	}

}
