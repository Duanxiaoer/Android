package duanqifeng.dachuang.bluecheck;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JOptionPane;

public class zuoyeSeverSocket extends Thread {

	@Override
	public void run() {
		zuoye();
	}
	
	public void zuoye(){
		//1-65535
				try {
					ServerSocket seversocket = new ServerSocket(12346);
					while(true)
					{
						//�������߳�
						Socket socket = seversocket.accept();
						JOptionPane.showMessageDialog(null, "�пͻ������ӱ�����ҵ�˿ڡ�������");
						//��socket���ݸ����߳�
						HomeworkSocket cs = new HomeworkSocket(socket);
						cs.start();
						HomeworkManger.getHomeworkManger().add(cs);
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
	}
}
