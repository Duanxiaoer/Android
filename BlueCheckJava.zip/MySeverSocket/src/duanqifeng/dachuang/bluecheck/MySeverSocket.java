package duanqifeng.dachuang.bluecheck;

public class MySeverSocket {

	public static void main(String[] args) {
		new zuoyeSeverSocket().start();
		new taolunSeverSocket().start();
		new qiandaocishuSeverSocket().start();
	}
}
