package duanqifeng.dachuang.bluecheck;

import java.util.Vector;

public class SignManger {
	
	JiLu jilu = new JiLu();
	
	private String ���� = "ǩ��";
	private SignManger(){}
	private static final SignManger cm = new SignManger();
	public static SignManger getSignManger(){
		return cm;
	}
	
	Vector<SignSocket> vector = new Vector<SignSocket>();
	
	public void add(SignSocket cs){
		vector.add(cs);
	}

	public void publish(SignSocket cs,String out){
		for(int i = 0;i<vector.size();i++){
			if(i == 0)
			jilu.jilu(����,out+"\n");
			SignSocket cschatsocket = vector.get(i);
			if(!cs.equals(cschatsocket)){
				cschatsocket.out(out);
			}
		}
	}
}
  