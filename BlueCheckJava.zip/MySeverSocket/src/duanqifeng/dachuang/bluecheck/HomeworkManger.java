package duanqifeng.dachuang.bluecheck;

import java.util.Vector;

public class HomeworkManger {
	
	JiLu jilu = new JiLu();
	
	private String ���� = "��ҵ";
	private HomeworkManger(){}
	private static final HomeworkManger cm = new HomeworkManger();
	public static HomeworkManger getHomeworkManger(){
		return cm;
	}
	
	Vector<HomeworkSocket> vector = new Vector<HomeworkSocket>();
	
	public void add(HomeworkSocket cs){
		vector.add(cs);
	}

	
	public void publish(HomeworkSocket cs,String out){
		for(int i = 0;i<vector.size();i++){
			if(i == 0)
			jilu.jilu(����,out+"\n");
			HomeworkSocket cschatsocket = vector.get(i);
			if(!cs.equals(cschatsocket)){
				cschatsocket.out(out);
			}
		}
	}
}
  