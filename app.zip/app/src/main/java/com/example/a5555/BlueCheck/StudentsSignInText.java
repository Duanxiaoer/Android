package com.example.a5555.BlueCheck;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;

public class StudentsSignInText extends AppCompatActivity {

    SharedPreferences sharedPreferences;
    TextView 显示作业;
    Boolean 连接状态;
    Socket socket;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_studentssignintext);
        连接状态 = false;
        //连接服务器并接收消息
        connectAndReceive();

        sharedPreferences = getSharedPreferences("bulecheck", MODE_PRIVATE);
        显示作业 = (TextView) findViewById(R.id.签到次数);
        Button 检查连接 = (Button) findViewById(R.id.检查次数连接);
        assert 显示作业 != null;
        assert 检查连接 != null;
        显示作业.append(sharedPreferences.getString("签到次数", "暂无.."));

        检查连接.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (连接状态) {
                    Toast.makeText(StudentsSignInText.this, "成功连接服务器", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(StudentsSignInText.this, "因为穷，所以用不起公网服务器，目前此功能只能用于同一台PC的模拟器上...", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(StudentsSignInText.this, Home.class));
                    finish();
                }
            }
        });
    }

    private void connectAndReceive() {
        AsyncTask<Void, String, Void> 接收作业 = new AsyncTask<Void, String, Void>() {

            String line_1 = "学生签到次数：\n";

            @Override
            protected Void doInBackground(Void... params) {
                try {
                    socket = new Socket("192.168.253.1", 12347);
                    连接状态 = true;

                    InputStream inputStream = socket.getInputStream();
                    InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                    String line;

                    while ((line = bufferedReader.readLine()) != null) {
                        //显示读取到的消息
                        line_1 = line_1 + line + "\n";
                        publishProgress(line);
                    }

                    bufferedReader.close();
                    inputStreamReader.close();
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            protected void onProgressUpdate(String... values) {
                //将信息保存在本地数据中
                SharedPreferences.Editor ed = sharedPreferences.edit();
                ed.putString("签到次数", line_1);
                ed.apply();
                显示作业 = (TextView) findViewById(R.id.签到次数);
                显示作业.append(sharedPreferences.getString("签到次数", "暂无.."));
            }
        };
        接收作业.execute();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (连接状态) {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
