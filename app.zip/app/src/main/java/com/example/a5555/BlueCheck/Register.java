package com.example.a5555.BlueCheck;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;


public class Register extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        final EditText 学号 = (EditText) findViewById(R.id.注册学号输入);
        final EditText 姓名 = (EditText) findViewById(R.id.注册姓名输入);
        final EditText 密码 = (EditText) findViewById(R.id.注册密码输入);
        final EditText 密码1 = (EditText) findViewById(R.id.注册密码输入1);
        assert 学号 != null;


        Button 重置 = (Button) findViewById(R.id.重置按钮);
        Button 注册 = (Button) findViewById(R.id.注册按钮);
        assert 重置 != null;
        assert 姓名 != null;
        assert 密码 != null;
        assert 密码1 != null;

        重置.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                学号.setText("");
                姓名.setText("");
                密码.setText("");
                密码1.setText("");

            }
        });



        assert 注册 != null;
        注册.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String S学号 = 学号.getText().toString();
                final String S姓名 = 姓名.getText().toString();
                final String S密码 = 密码.getText().toString();
                final String S密码1 = 密码1.getText().toString();

                if (!(!"".equals(S学号) && !"".equals(S姓名) && !"".equals(S密码) && !"".equals(S密码1))) {
                    Toast.makeText(Register.this, "请将资料填完整！", Toast.LENGTH_LONG).show();
                } else {
                    if (S学号.length() != 13) {
                        Toast.makeText(Register.this, "学号不正确！", Toast.LENGTH_LONG).show();
                        学号.setText("");
                        学号.requestFocus();
                    } else {
                        //用户数据文件名
                        final String 文件名 = "UserInfo";
                        //默认为未注册
                        Users.setNumberDecide(0);
                        //在用户数据文件中检测该学号是否已经注册
                        try {
                            FileInputStream fileInputStream = openFileInput(文件名);
                            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream, "UTF-8");
                            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                            String line;
                            while (!((line = bufferedReader.readLine()) == null)) {
                                if (line.equals(S学号)) {
                                    //已注册赋值为1
                                    Users.setNumberDecide(1);
                                }
                            }
                            inputStreamReader.close();
                            fileInputStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        //根据检索结果判断是否已经注册
                        if (Users.getNumberDecide() == 1) {
                            Toast.makeText(Register.this, "该学号已注册！", Toast.LENGTH_LONG).show();
                            学号.setText("");
                            学号.requestFocus();
                        } else {
                            if (S密码.equals(S密码1)) {
                                new Thread() {
                                    @Override
                                    public void run() {
                                        //满足注册条件后即写入用户数据
                                        try {
                                            FileOutputStream fileOutputStream = openFileOutput(文件名, Context.MODE_APPEND);
                                            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(fileOutputStream, "UTF-8");
                                            outputStreamWriter.write(S学号+"\n"+S姓名+"\n"+S密码+"\n");
                                            outputStreamWriter.flush();
                                            fileOutputStream.flush();
                                            outputStreamWriter.close();
                                            fileOutputStream.close();
                                        } catch (IOException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }.start();
                                Toast.makeText(getApplicationContext(), "注册成功", Toast.LENGTH_LONG).show();
                                startActivity(new Intent(Register.this, MainActivity.class));
                                finish();
                            } else {
                                Toast.makeText(Register.this, "两次输入的密码不相同！！！", Toast.LENGTH_LONG).show();
                                密码.requestFocus();
                            }
                        }
                    }
                }


            }
        });
    }
}
