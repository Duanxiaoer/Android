package com.example.a5555.BlueCheck;

import android.annotation.TargetApi;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Arrays;
import java.util.Set;

public class SignIn extends AppCompatActivity {

    private BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    String BluetoothDevicesNameArray[] = new String[100];
    String BluetoothDevicesArray[] = new String[100];
    String 签到表 = "签到表.txt";
    Boolean 连接状态 = false;
    static Boolean 签到结束 = false;
    BufferedWriter writer;
    static int a = 0;
    Socket socket;


    @TargetApi(Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        connect();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        if (pairedDevices.size() > 0) {
            for (BluetoothDevice devices : pairedDevices) {
                if (BluetoothDevicesNameArray[a] == null) {
                    BluetoothDevicesNameArray[a] = devices.getName();
                    BluetoothDevicesArray[a] = devices.getName() + "*" + devices.getAddress();
                    a += 1;
                }
            }
        } else {
            BluetoothDevicesNameArray[0] = "无已连接设备";
        }

        Button 已配对的设备 = (Button) findViewById(R.id.搜索蓝牙按钮);
        Button 搜索结束 = (Button) findViewById(R.id.搜索结束);
        assert 搜索结束 != null;
        assert 已配对的设备 != null;

        搜索结束.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                签到结束 = true;
                if (连接状态) {

                    try {

                        writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

                        FileInputStream fileInputStream = openFileInput(签到表);
                        InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream, "UTF-8");
                        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                        String line;
                        while (!((line = bufferedReader.readLine()) == null)) {
                            writer.write(line);
                        }
                        writer.flush();
                        inputStreamReader.close();
                        fileInputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                } else {
                    Toast.makeText(SignIn.this, "连接服务器后数据才能上传...", Toast.LENGTH_LONG).show();
                }

            }
        });

        已配对的设备.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (bluetoothAdapter.getState() == BluetoothAdapter.STATE_ON || bluetoothAdapter.getState() == BluetoothAdapter.STATE_TURNING_ON) {
                    setProgressBarIndeterminateVisibility(true);
                    setTitle("正在搜索....");
                    if (bluetoothAdapter.isDiscovering()) {
                        bluetoothAdapter.cancelDiscovery();
                    }
                    bluetoothAdapter.startDiscovery();
                }else{
                    Toast.makeText(getApplicationContext(), "蓝牙未开启，请确保飞行模式处于关闭状态.....", Toast.LENGTH_LONG).show();
                }

            }
        });


        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        this.registerReceiver(receiver, filter);

        IntentFilter filter1 = new IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        this.registerReceiver(receiver, filter1);


    }

    private void connect() {
        AsyncTask<Void, String, Void> 连接 = new AsyncTask<Void, String, Void>() {

            @Override
            protected Void doInBackground(Void... params) {
                try {
                    socket = new Socket("192.168.253.1", 12347);
                    连接状态 = true;
                    writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            protected void onProgressUpdate(String... values) {
            }
        };
        连接.execute();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (连接状态) {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    private final BroadcastReceiver receiver = new MyReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (device.getBondState() != BluetoothDevice.BOND_BONDED) {
                    if (BluetoothDevicesNameArray[a] == null) {
                        BluetoothDevicesNameArray[a] = device.getName() + ":" + device.getAddress();
                        a += 1;
                    }
                }
            } else {
                if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                    setProgressBarVisibility(false);
                    setTitle("搜索完成");
                    String 签到表 = "签到表.txt";
                    try {
                        FileOutputStream fileOutputStream = openFileOutput(签到表, MODE_APPEND);
                        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(fileOutputStream, "UTF-8");
                        int i = 0;
                        String 学生姓名[] = new String[a];
                        String 设备信息[] = new String[a];
                        do {
                            设备信息[i] = BluetoothDevicesArray[i];
                            学生姓名[i] = "姓名：" + BluetoothDevicesNameArray[i] + "\n";
                            i++;
                        } while (BluetoothDevicesNameArray[i] != null);
                        TextView 在座学生信息 = (TextView) findViewById(R.id.在座学生信息);
                        assert 在座学生信息 != null;
                        在座学生信息.setText(Arrays.toString(学生姓名));
                        outputStreamWriter.append(Arrays.toString(设备信息));
                        outputStreamWriter.flush();
                        fileOutputStream.flush();
                        outputStreamWriter.close();
                        fileOutputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    };
}
