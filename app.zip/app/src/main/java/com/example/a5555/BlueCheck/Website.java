package com.example.a5555.BlueCheck;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Website extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_website);

        final Button 百度 = (Button) findViewById(R.id.百度);
        final Button 知乎 = (Button) findViewById(R.id.知乎);
        final Button 批改网 = (Button) findViewById(R.id.批改网);
        final Button 教务处 = (Button) findViewById(R.id.教务处);
        final Button 计算机学院 = (Button) findViewById(R.id.计算机学院);
        final Button 绩点 = (Button) findViewById(R.id.绩点);

        new Thread() {
            @Override
            public void run() {


                assert 百度 != null;
                百度.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.baidu.com")));


                    }
                });
                assert 知乎 != null;
                知乎.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.zhihu.com")));


                    }
                });
                assert 教务处 != null;
                教务处.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://zhjw.scu.edu.cn/login.jsp")));


                    }
                });
                assert 批改网 != null;
                批改网.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://pigai.org/")));


                    }
                });
                assert 计算机学院 != null;
                计算机学院.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://cs.scu.edu.cn/")));


                    }
                });
                assert 绩点 != null;
                绩点.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://gpa.fyscu.com/home/account/login.html")));


                    }
                });

            }
        }.start();
    }
}
