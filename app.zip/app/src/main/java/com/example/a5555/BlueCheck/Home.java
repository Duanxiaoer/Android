package com.example.a5555.BlueCheck;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        final BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        final SharedPreferences sharedPreferences = getSharedPreferences("bluecheck",MODE_PRIVATE);

        /*//开启蓝牙
        bluetoothAdapter.enable();
        //反馈用户
        if (bluetoothAdapter.getState() == BluetoothAdapter.STATE_ON ||bluetoothAdapter.getState() == BluetoothAdapter.STATE_TURNING_ON){
            if (bluetoothAdapter.getState() == BluetoothAdapter.STATE_ON){
                bluetoothAdapter.setName(sharedPreferences.getString("用户名称","未知用户"));
                Toast.makeText(getApplicationContext(),"校对用户名成功！",Toast.LENGTH_LONG).show();
            }else{
                Toast.makeText(getApplicationContext(),"正在开启蓝牙，请稍等片刻......",Toast.LENGTH_LONG).show();
            }
        }else{
            Toast.makeText(getApplicationContext(),"蓝牙未开启，请确保飞行模式处于关闭状态....." ,Toast.LENGTH_LONG).show();
        }*/

        TextView 学号 = (TextView) findViewById(R.id.显示学号);
        assert 学号 != null;
        学号.setText("学号："+ sharedPreferences.getString("用户学号","无"));
        TextView 姓名 = (TextView) findViewById(R.id.显示姓名);
        assert 姓名 != null;
        姓名.setText("姓名："+ sharedPreferences.getString("用户名称", "无"));
        Button 网站 = (Button) findViewById(R.id.网站按钮);
        Button 签到 = (Button) findViewById(R.id.签到按钮);
        Button 我 = (Button) findViewById(R.id.我的按钮);
        Button 学生签到次数 = (Button) findViewById(R.id.查看签到次数按钮);
        Button 作业 = (Button) findViewById(R.id.作业按钮);
        Button 关于 = (Button) findViewById(R.id.关于按钮);
        Button 讨论 = (Button) findViewById(R.id.讨论按钮);


        assert 讨论 != null;
        讨论.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Home.this,Discuss.class));
            }
        });
        assert 学生签到次数 != null;
        学生签到次数.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Home.this,StudentsSignInText.class));
            }
        });
        assert 签到 != null;
        签到.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               startActivity(new Intent(Home.this,SignIn.class));
            }
        });
        assert 作业 != null;
        作业.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Home.this,Homework.class));
            }
        });
        assert 我 != null;
        我.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Home.this,Myself.class));
            }
        });
        assert 关于 != null;
        关于.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Home.this,About.class));
            }
        });
        assert 网站 != null;
        网站.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Home.this,Website.class));
            }
        });

    }
}
