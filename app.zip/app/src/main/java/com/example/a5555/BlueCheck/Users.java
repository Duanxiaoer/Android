package com.example.a5555.BlueCheck;

public class Users {
    static private String name;
    static private String number;
    static private int numberDecide;


    public String getNumber() {

        return number;
    }

    public void setNumber(String number) {
        Users.number = number;
    }

    public String getName() {

        return name;
    }

    public static int getNumberDecide() {
        return numberDecide;
    }

    public static void setNumberDecide(int numberDecide) {
   /*
         注册时的返回值的意义
           1    存在
           0    不存在
         登录时的返回值的意义
           0    不存在
           10   密码错误
           11   学号密码匹配*/
        Users.numberDecide = numberDecide;
    }


    public void setName(String name) {
        Users.name = name;
    }
}
