package com.example.a5555.BlueCheck;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;


public class Welcome extends AppCompatActivity {

    private static final int TIME = 2000;
    private static final int GO_MAIN = 1000;
    private static final int GO_ZHUYE = 1010;
    SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        init();
    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case GO_MAIN:
                    gomain();
                    break;
                case GO_ZHUYE:
                    gozhuye();
                    break;
            }
        }
    };

    private void init() {

        sharedPreferences = getSharedPreferences("bluecheck",MODE_PRIVATE);
        boolean isFirstIn = sharedPreferences.getBoolean("isFirstIn", true);
        if (!isFirstIn) {
            handler.sendEmptyMessageDelayed(GO_ZHUYE, TIME);
        } else {
            handler.sendEmptyMessageDelayed(GO_MAIN, TIME);
        }
    }

    private void gomain() {
        Intent i = new Intent(Welcome.this, MainActivity.class);
        startActivity(i);
        finish();
    }

    private void gozhuye() {
        Intent i = new Intent(Welcome.this, Home.class);
        startActivity(i);
        finish();
    }
}
