package com.example.a5555.BlueCheck;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;


public class MainActivity extends AppCompatActivity {

    //定义用户对象以便访问方法
    final Users 用户 = new Users();
    SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        sharedPreferences = getSharedPreferences("bluecheck", MODE_PRIVATE);

        Button 登录 = (Button) findViewById(R.id.登录按钮);
        Button 注册 = (Button) findViewById(R.id.注册按钮);

        assert 登录 != null;
        登录.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final EditText 学号输入框 = (EditText) findViewById(R.id.学号输入框);
                final EditText 密码输入框 = (EditText) findViewById(R.id.密码输入框);

                assert 学号输入框 != null;
                assert 密码输入框 != null;
                final String 学号 = 学号输入框.getText().toString();
                final String 密码 = 密码输入框.getText().toString();

                if (!"".equals(学号) && !"".equals(密码)) {
                    //用户数据文件
                    final String 文件名 = "UserInfo";
                    //默认未注册
                    Users.setNumberDecide(0);
                    //从用户数据文件中查找用户学号
                    try {
                        FileInputStream fileInputStream = openFileInput(文件名);
                        InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream, "UTF-8");
                        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                        String line, name;
                        while (!((line = bufferedReader.readLine()) == null)) {
                            System.err.println("11111111111111111111111111111111111111111111111111111111111111111111111111");
                            if (line.equals(学号)) {
                                System.err.println("22222222222222222222222222222222222222222222222222222222222222222222222");
                                //查找到学号后默认密码错误
                                Users.setNumberDecide(10);
                                name = bufferedReader.readLine();
                                //检索学号
                                if ((bufferedReader.readLine()).equals(密码)) {
                                    Users.setNumberDecide(11);
                                }
                                用户.setNumber(学号);
                                //存储到系统缓存
                                SharedPreferences.Editor ed = sharedPreferences.edit();
                                ed.putString("用户学号", 用户.getNumber());
                                //继续读出用户名称
                                用户.setName(name);
                                //存储到系统缓存
                                ed.putString("用户名称", 用户.getName());
                                ed.apply();
                                break;
                            } else {
                                Users.setNumberDecide(0);
                                System.err.println("333333333333333333333333333333333333333333333333333333333333333333333333");
                            }
                        }
                        inputStreamReader.close();
                        fileInputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    switch (Users.getNumberDecide()) {
                        case 0:
                            Toast.makeText(MainActivity.this, "没有找到该用户，请注册！", Toast.LENGTH_LONG).show();
                            break;
                        case 10:
                            Toast.makeText(MainActivity.this, "密码错误，请重新输入！", Toast.LENGTH_LONG).show();
                            密码输入框.setText("");
                            密码输入框.requestFocus();
                            break;
                        case 11:
                            Intent intent = new Intent(MainActivity.this, Home.class);
                            SharedPreferences.Editor ed = sharedPreferences.edit();
                            ed.putBoolean("isFirstIn", false);
                            ed.apply();
                            startActivity(intent);
                            finish();
                            break;
                        default:
                            Toast.makeText(MainActivity.this, "我也晓不得这是啥错误！", Toast.LENGTH_LONG).show();
                    }

                } else {
                    Toast.makeText(MainActivity.this, "学号和密码不能为空", Toast.LENGTH_LONG).show();
                }
            }
        });

        assert 注册 != null;
        注册.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Register.class));
                finish();
            }
        });
    }
}
