package com.example.a5555.BlueCheck;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class DiscussionText extends AppCompatActivity {

    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discussiontext);

        sharedPreferences = getSharedPreferences("bluecheck", MODE_PRIVATE);
        TextView 讨论记录框 = (TextView) findViewById(R.id.讨论记录);

        try {
            String 当前用户讨论记录文件名 = sharedPreferences.getString("用户名称","未知用户")+"讨论记录.txt";
            InputStream inputStream = openFileInput(当前用户讨论记录文件名);
            InputStreamReader isr = new InputStreamReader(inputStream);
            BufferedReader br = new BufferedReader(isr);
            String line;
            String line_1 = "";
            while((line = br.readLine()) != null){
                //缓存
                line_1 = line_1 + line+"\n";
                assert 讨论记录框 != null;
                讨论记录框.append(line+"\n");
            }
            //存入缓存
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("讨论记录", line_1);
            editor.apply();
            br.close();
            isr.close();
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
