package com.example.a5555.BlueCheck;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class Homework extends AppCompatActivity {

    SharedPreferences sharedPreferences;
    TextView 显示作业;
    Boolean 连接状态;
    Socket socket;
    BufferedReader reader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homework);

        sharedPreferences = getSharedPreferences("bulecheck", MODE_PRIVATE);
        连接状态 = false;
        //连接服务器并接收消息
        connectAndReceive();

        显示作业 = (TextView) findViewById(R.id.作业);
        Button 检查作业连接 = (Button) findViewById(R.id.检查作业连接);
        assert 显示作业 != null;
        assert 检查作业连接 != null;
        显示作业.append(sharedPreferences.getString("作业", "暂无作业.."));

        检查作业连接.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (连接状态) {
                    Toast.makeText(Homework.this, "成功连接服务器", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(Homework.this, "因为暂未使用公网服务器，所以目前此功能只能用于同一台PC的模拟器上...", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void connectAndReceive() {
        AsyncTask<Void, String, Void> read = new AsyncTask<Void, String, Void>() {
            @Override
            protected Void doInBackground(Void... params) {
                try {
                    //设置服务器ip地址和连接端口
                    socket = new Socket("10.0.2.2.", 12346);

                    连接状态 = true;
                    reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                    //读写服务器端传来的消息
                    String line;
                    while ((line = reader.readLine()) != null) {
                        //显示读取到的消息
                        publishProgress(line + "\n");
                        //将消息记录到本地记录数据
                        SharedPreferences.Editor ed = sharedPreferences.edit();
                        ed.putString("作业",sharedPreferences.getString("作业","作业：\n")+line+"\n");
                        ed.apply();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            //显示从服务器读到的消息
            @Override
            protected void onProgressUpdate(final String... values) {
                显示作业.append(values[0]);
            }
        };
        read.execute();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (连接状态) {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


}
