package com.example.a5555.BlueCheck;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.Socket;

public class Homework extends AppCompatActivity {

    Button 发送;
    EditText 作业编辑框;
    TextView 作业显示;
    Socket socket;
    Boolean 连接状态;
    Writer writer;
    String 我发布的作业;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        连接状态  = false;
        connectAndReceive();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homework);

        sharedPreferences = getSharedPreferences("bluecheck", MODE_PRIVATE);
        发送 = (Button) findViewById(R.id.发布作业按钮);
        作业显示 = (TextView) findViewById(R.id.作业);
        作业编辑框 = (EditText) findViewById(R.id.发布作业编辑框);

        发送.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (连接状态){
                    我发布的作业 = 作业编辑框.getText().toString()+"\n";
                    send();
                    作业显示.append("\n作业："+我发布的作业);
                    作业编辑框.setText("");
                }else{
                    Toast.makeText(Homework.this, "因为暂未使用公网服务器，所以此功能目前仅在PC模拟器上可用...", Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    public void connectAndReceive() {
        AsyncTask<Void, String, Void> read = new AsyncTask<Void, String, Void>() {
            @Override
            protected Void doInBackground(Void... params) {
                    //设置服务器ip地址和连接端口
                try {
                    socket = new Socket("10.0.2.2", 12346);
                    连接状态 = true;
                    writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }
        };
        read.execute();
    }


    public void send() {
        try {
            writer.write(sharedPreferences.getString("用户名称", "未知用户") + ":" + 我发布的作业);
            //将消息记录到本地聊天记录
            try {
                final String 当前用户记录文件名 = sharedPreferences.getString("用户名称", "未知用户") + "作业记录.txt";
                FileOutputStream fileOutputStream = openFileOutput(当前用户记录文件名, Context.MODE_APPEND);
                OutputStreamWriter outputStreamWriter = new OutputStreamWriter(fileOutputStream);
                outputStreamWriter.append("我：").append(我发布的作业);
                outputStreamWriter.flush();
                fileOutputStream.close();
                outputStreamWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
