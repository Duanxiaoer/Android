package com.example.a5555.BlueCheck;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class Discuss extends AppCompatActivity {

    EditText 我的信息编辑框;
    TextView 聊天记录;
    String 我发送的信息;
    static Boolean 连接状态;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discuss);

        sharedPreferences = getSharedPreferences("bluecheck", MODE_PRIVATE);
        Button 发送按钮 = (Button) findViewById(R.id.发送按钮);
        Button 讨论记录 = (Button) findViewById(R.id.讨论记录按钮);

        我的信息编辑框 = (EditText) findViewById(R.id.我的信息);
        聊天记录 = (TextView) findViewById(R.id.聊天记录);
        连接状态 = false;

        //连接服务器并接收消息
        connectAndReceive();

        assert 讨论记录 != null;
        讨论记录.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Discuss.this, DiscussionText.class));
            }
        });

        assert 发送按钮 != null;
        发送按钮.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (连接状态) {
                    我发送的信息 = 我的信息编辑框.getText().toString() + "\n";
                    聊天记录.append("我：" + 我发送的信息);
                    //发送消息
                    send();
                    我的信息编辑框.setText("");

                }else{
                    Toast.makeText(Discuss.this,"因为暂未使用公网服务器，所以目前此功能只能用于同一台PC的模拟器上...",Toast.LENGTH_LONG).show();
                }

            }
        });

        //将上一次的讨论记录显示
        聊天记录.append(sharedPreferences.getString("讨论记录", ""));
        System.err.println("oncreat                                         ");

    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    Socket socket = null;
    BufferedWriter writer = null;
    BufferedReader reader = null;

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (连接状态){

            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.err.println("onDestroy                                         ");
        }

    }

    public void connectAndReceive() {
        AsyncTask<Void, String, Void> read = new AsyncTask<Void, String, Void>() {
            @Override
            protected Void doInBackground(Void... params) {
                try {
                    //设置服务器ip地址和连接端口
                    socket = new Socket("10.0.2.2", 12345);

                    连接状态 = true;
                    writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
                    reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                    //读写服务器端传来的消息
                    String line;
                    while ((line = reader.readLine()) != null) {
                        //显示读取到的消息
                        publishProgress(line + "\n");
                        //将消息记录到本地聊天记录文件
                        try {
                            //文件
                            String 当前用户讨论记录文件名 = sharedPreferences.getString("用户名称","未知用户")+"讨论记录.txt";
                            FileOutputStream fileOutputStream = openFileOutput(当前用户讨论记录文件名, Context.MODE_APPEND);
                            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(fileOutputStream);
                            outputStreamWriter.append(line).append("\n");
                            outputStreamWriter.flush();
                            fileOutputStream.close();
                            outputStreamWriter.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            //显示从服务器读到的消息
            @Override
            protected void onProgressUpdate(final String... values) {
                聊天记录.append(values[0]);
            }
        };
        read.execute();
    }

    public void send() {
        try {
            writer.write(sharedPreferences.getString("用户名称", "未知用户") + ":" + 我发送的信息);
            //将消息记录到本地聊天记录
            try {
                final String 当前用户讨论记录文件名 = sharedPreferences.getString("用户名称","未知用户")+"讨论记录.txt";
                FileOutputStream fileOutputStream = openFileOutput(当前用户讨论记录文件名, Context.MODE_APPEND);
                OutputStreamWriter outputStreamWriter = new OutputStreamWriter(fileOutputStream);
                outputStreamWriter.append("我：").append(我发送的信息);
                outputStreamWriter.flush();
                fileOutputStream.close();
                outputStreamWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            //writer.flush();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
